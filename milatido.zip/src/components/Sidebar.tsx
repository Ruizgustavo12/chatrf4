import { 
  Users, 
  Home, 
  Search, 
  PlaySquare, 
  Store, 
  Gamepad2,
  ChevronDown,
  Bookmark,
  History,
  Bot,
  Sparkles
} from 'lucide-react';
import { UserProfile } from '../types';
import { cn } from '../lib/utils';

interface SidebarProps {
  profile: UserProfile;
  onOpenWall: (profile: UserProfile) => void;
}

export function Sidebar({ profile, onOpenWall }: SidebarProps) {
  const menuItems = [
    { icon: Users, label: 'Amigos', color: 'text-blue-500' },
    { icon: Bot, label: 'Meta AI', color: 'text-purple-500' },
    { icon: Sparkles, label: 'Manus AI', color: 'text-orange-500' },
    { icon: History, label: 'Recuerdos', color: 'text-blue-500' },
    { icon: Bookmark, label: 'Guardado', color: 'text-purple-600' },
  ];

  return (
    <aside className="hidden lg:flex flex-col w-80 h-full overflow-y-auto p-2 scrollbar-hide">
      <div className="space-y-1">
        <button 
          onClick={() => onOpenWall(profile)}
          className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-200 transition-colors"
        >
          <img src={profile.avatar} className="w-9 h-9 rounded-full object-cover border border-gray-200" />
          <span className="font-semibold text-sm">{profile.name}</span>
        </button>

        {menuItems.map((item, idx) => (
          <button 
            key={idx}
            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-200 transition-colors"
          >
            <item.icon className={cn("w-7 h-7", item.color)} />
            <span className="font-semibold text-sm">{item.label}</span>
          </button>
        ))}

        <button className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-200 transition-colors">
          <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center">
            <ChevronDown size={20} />
          </div>
          <span className="font-semibold text-sm">Ver más</span>
        </button>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-300">
        <h3 className="px-3 text-gray-500 font-bold text-sm mb-2">Tus accesos directos</h3>
        <button className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-200 transition-colors">
          <div className="w-9 h-9 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
            M
          </div>
          <span className="font-semibold text-sm">MiLatido Community</span>
        </button>
      </div>

      <footer className="mt-auto p-3 text-[12px] text-gray-500 leading-relaxed">
        Privacidad · Condiciones · Publicidad · Opciones de anuncios · Cookies · Más · MiLatido © 2026
      </footer>
    </aside>
  );
}
