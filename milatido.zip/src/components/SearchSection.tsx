import { useState, useEffect } from 'react';
import { 
  collection, 
  getDocs, 
  query, 
  where, 
  limit 
} from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile } from '../types';
import { Search, UserPlus, MessageCircle } from 'lucide-react';

interface SearchProps {
  user: any;
  profile: UserProfile;
  onOpenWall: (profile: UserProfile) => void;
}

export function SearchSection({ user, profile, onOpenWall }: SearchProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!searchTerm.trim()) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, 'users'), 
        where('name', '>=', searchTerm),
        where('name', '<=', searchTerm + '\uf8ff'),
        limit(10)
      );
      const snap = await getDocs(q);
      setResults(snap.docs.map(d => d.data() as UserProfile).filter(u => u.uid !== user.uid));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-[600px] mx-auto p-4 space-y-6">
      <div className="bg-white p-4 rounded-lg shadow flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
          <input 
            type="text" 
            placeholder="Buscar personas..." 
            className="w-full bg-gray-100 rounded-full pl-10 pr-4 py-2 outline-none"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
        </div>
        <button 
          onClick={handleSearch}
          className="bg-[#1877f2] text-white px-6 py-2 rounded-full font-bold hover:bg-[#166fe5]"
        >
          Buscar
        </button>
      </div>

      <div className="space-y-2">
        <h3 className="text-lg font-bold px-2">Resultados</h3>
        {loading ? (
          <div className="flex justify-center p-10">
            <div className="w-8 h-8 border-4 border-[#1877f2] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : results.length > 0 ? (
          results.map(u => (
            <div key={u.uid} className="bg-white p-4 rounded-lg shadow flex items-center justify-between">
              <div 
                className="flex items-center gap-3 cursor-pointer group"
                onClick={() => onOpenWall(u)}
              >
                <img src={u.avatar} className="w-14 h-14 rounded-full border" />
                <div>
                  <p className="font-bold group-hover:underline">{u.name}</p>
                  <p className="text-sm text-gray-500">{u.city || 'Sin ubicación'}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="bg-gray-200 p-2 rounded-lg hover:bg-gray-300">
                  <UserPlus size={20} />
                </button>
                <button className="bg-gray-200 p-2 rounded-lg hover:bg-gray-300">
                  <MessageCircle size={20} />
                </button>
              </div>
            </div>
          ))
        ) : searchTerm && (
          <p className="text-center text-gray-500 py-10">No se encontraron resultados para "{searchTerm}"</p>
        )}
      </div>
    </div>
  );
}
