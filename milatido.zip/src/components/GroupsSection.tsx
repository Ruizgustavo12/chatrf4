import { useState, useEffect } from 'react';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy, 
  addDoc, 
  serverTimestamp,
  doc,
  updateDoc,
  arrayUnion,
  arrayRemove,
  deleteDoc,
  where
} from 'firebase/firestore';
import { db } from '../firebase';
import { Group, UserProfile } from '../types';
import { formatDate, cn } from '../lib/utils';
import { 
  Users, 
  Plus, 
  Search, 
  Globe, 
  Lock, 
  MoreHorizontal,
  UserPlus,
  Check,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

interface GroupsProps {
  user: any;
  profile: UserProfile;
}

export function GroupsSection({ user, profile }: GroupsProps) {
  const [groups, setGroups] = useState<Group[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPrivacy, setNewPrivacy] = useState<'public' | 'private'>('public');

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'groups'), (snap) => {
      setGroups(snap.docs.map(d => ({ id: d.id, ...d.data() } as Group)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'groups'));
    return unsub;
  }, []);

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    try {
      await addDoc(collection(db, 'groups'), {
        name: newName,
        description: newDesc,
        adminUid: user.uid,
        members: [user.uid],
        pendingRequests: [],
        privacy: newPrivacy,
        ts: Date.now(),
        cover: `https://picsum.photos/seed/${newName}/800/200`
      });
      setIsCreating(false);
      setNewName('');
      setNewDesc('');
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'groups');
    }
  };

  const joinGroup = async (group: Group) => {
    const groupRef = doc(db, 'groups', group.id);
    try {
      if (group.privacy === 'public') {
        await updateDoc(groupRef, {
          members: arrayUnion(user.uid)
        });
      } else {
        await updateDoc(groupRef, {
          pendingRequests: arrayUnion(user.uid)
        });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `groups/${group.id}`);
    }
  };

  return (
    <div className="flex h-[calc(100vh-56px)] bg-[#f0f2f5]">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r flex flex-col p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Grupos</h2>
          <button className="p-2 bg-gray-100 rounded-full hover:bg-gray-200"><Search size={20} /></button>
        </div>
        
        <button 
          onClick={() => setIsCreating(true)}
          className="w-full bg-blue-50 text-[#1877f2] py-2 rounded-lg font-bold flex items-center justify-center gap-2 hover:bg-blue-100 transition-colors"
        >
          <Plus size={20} /> Crear nuevo grupo
        </button>

        <div className="space-y-1 overflow-y-auto">
          <h3 className="font-bold text-sm text-gray-500 px-2 py-2">Tus grupos</h3>
          {groups.filter(g => g.members.includes(user.uid)).map(g => (
            <button key={g.id} className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors">
              <img src={g.cover} className="w-12 h-12 rounded-lg object-cover" />
              <div className="text-left">
                <p className="font-semibold text-sm">{g.name}</p>
                <p className="text-xs text-gray-500">Última actividad hace poco</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-[1000px] mx-auto space-y-6">
          <h3 className="text-xl font-bold">Sugerencias para ti</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {groups.filter(g => !g.members.includes(user.uid)).map(g => (
              <div key={g.id} className="bg-white rounded-xl shadow overflow-hidden flex flex-col">
                <img src={g.cover} className="h-32 w-full object-cover" />
                <div className="p-4 flex-1 flex flex-col">
                  <h4 className="font-bold text-lg mb-1">{g.name}</h4>
                  <p className="text-sm text-gray-500 mb-4 flex-1 line-clamp-2">{g.description || 'Sin descripción'}</p>
                  <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
                    {g.privacy === 'public' ? <Globe size={14} /> : <Lock size={14} />}
                    <span>{g.privacy === 'public' ? 'Grupo público' : 'Grupo privado'}</span>
                    <span>·</span>
                    <span>{g.members.length} miembros</span>
                  </div>
                  <button 
                    onClick={() => joinGroup(g)}
                    className="w-full bg-gray-200 py-2 rounded-lg font-bold hover:bg-gray-300 transition-colors"
                  >
                    {g.pendingRequests?.includes(user.uid) ? 'Solicitud enviada' : 'Unirse al grupo'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Create Group Modal */}
      <AnimatePresence>
        {isCreating && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-xl shadow-2xl w-full max-w-[500px] overflow-hidden"
            >
              <div className="p-4 border-b flex items-center justify-between">
                <h3 className="text-xl font-bold">Crear grupo</h3>
                <button onClick={() => setIsCreating(false)} className="p-2 bg-gray-100 rounded-full hover:bg-gray-200">
                  <X size={20} />
                </button>
              </div>
              <form onSubmit={handleCreateGroup} className="p-4 space-y-4">
                <input 
                  type="text" 
                  placeholder="Nombre del grupo" 
                  className="w-full p-3 border rounded-lg outline-none focus:border-blue-500"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  required
                />
                <textarea 
                  placeholder="Descripción (opcional)" 
                  className="w-full p-3 border rounded-lg outline-none focus:border-blue-500 min-h-[100px]"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                />
                <div className="space-y-2">
                  <p className="font-bold text-sm text-gray-600">Privacidad</p>
                  <div className="flex gap-2">
                    <button 
                      type="button"
                      onClick={() => setNewPrivacy('public')}
                      className={cn(
                        "flex-1 p-3 border rounded-lg flex items-center gap-2 transition-colors",
                        newPrivacy === 'public' ? "border-blue-500 bg-blue-50" : "hover:bg-gray-50"
                      )}
                    >
                      <Globe size={20} />
                      <div className="text-left">
                        <p className="font-bold text-sm">Público</p>
                        <p className="text-[10px] text-gray-500">Cualquiera puede ver el grupo</p>
                      </div>
                    </button>
                    <button 
                      type="button"
                      onClick={() => setNewPrivacy('private')}
                      className={cn(
                        "flex-1 p-3 border rounded-lg flex items-center gap-2 transition-colors",
                        newPrivacy === 'private' ? "border-blue-500 bg-blue-50" : "hover:bg-gray-50"
                      )}
                    >
                      <Lock size={20} />
                      <div className="text-left">
                        <p className="font-bold text-sm">Privado</p>
                        <p className="text-[10px] text-gray-500">Solo miembros pueden ver</p>
                      </div>
                    </button>
                  </div>
                </div>
                <button 
                  type="submit"
                  className="w-full bg-[#1877f2] text-white py-3 rounded-lg font-bold hover:bg-[#166fe5] transition-colors"
                >
                  Crear
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
