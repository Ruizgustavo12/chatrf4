import { useState } from 'react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword 
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { motion } from 'motion/react';

export function AuthSection() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleGoogleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (!userDoc.exists()) {
        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          name: user.displayName || 'Usuario',
          email: user.email,
          avatar: user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`,
          friends: [],
          friendRequests: [],
          ts: Date.now()
        });
      }
    } catch (e: any) {
      setError(e.message);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        const result = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, 'users', result.user.uid), {
          uid: result.user.uid,
          name: name,
          email: email,
          avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${result.user.uid}`,
          friends: [],
          friendRequests: [],
          ts: Date.now()
        });
      }
    } catch (e: any) {
      setError(e.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#f0f2f5] flex flex-col lg:flex-row items-center justify-center p-4 lg:p-20 gap-10 lg:gap-40">
      <div className="max-w-md text-center lg:text-left">
        <h1 className="text-[#1877f2] text-6xl font-bold mb-4">MiLatido</h1>
        <p className="text-2xl text-gray-700 leading-tight">
          MiLatido te ayuda a comunicarte y compartir con las personas que forman parte de tu vida.
        </p>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-4 rounded-lg shadow-xl w-full max-w-[400px]"
      >
        <form onSubmit={handleEmailAuth} className="space-y-4">
          {!isLogin && (
            <input
              type="text"
              placeholder="Nombre completo"
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:border-[#1877f2]"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          )}
          <input
            type="email"
            placeholder="Correo electrónico"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:border-[#1877f2]"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Contraseña"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:border-[#1877f2]"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button className="w-full bg-[#1877f2] text-white py-3 rounded-md text-xl font-bold hover:bg-[#166fe5] transition-colors">
            {isLogin ? 'Iniciar sesión' : 'Registrarte'}
          </button>
          
          {error && <p className="text-red-500 text-sm text-center">{error}</p>}
          
          <div className="text-center">
            <a href="#" className="text-[#1877f2] text-sm hover:underline">¿Olvidaste tu contraseña?</a>
          </div>
          
          <hr className="my-4" />
          
          <button 
            type="button"
            onClick={() => setIsLogin(!isLogin)}
            className="w-full bg-[#42b72a] text-white py-3 rounded-md text-lg font-bold hover:bg-[#36a420] transition-colors"
          >
            {isLogin ? 'Crear cuenta nueva' : 'Ya tengo una cuenta'}
          </button>
        </form>
        
        <div className="mt-4">
          <button 
            onClick={handleGoogleLogin}
            className="w-full flex items-center justify-center gap-2 border border-gray-300 py-2 rounded-md hover:bg-gray-50 transition-colors"
          >
            <img src="https://www.google.com/favicon.ico" className="w-4 h-4" alt="Google" />
            Continuar con Google
          </button>
        </div>
      </motion.div>
    </div>
  );
}
