import { useState, useEffect, useRef } from 'react';
import { 
  collection, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  addDoc, 
  serverTimestamp,
  doc,
  getDocs,
  limit
} from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile, Chat, Message } from '../types';
import { formatDate, cn } from '../lib/utils';
import { 
  Send, 
  Image as ImageIcon, 
  Smile, 
  Phone, 
  Video, 
  Info,
  Search,
  MoreHorizontal,
  Plus,
  MessageCircle
} from 'lucide-react';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

interface ChatProps {
  user: any;
  profile: UserProfile;
}

export function ChatSection({ user, profile }: ChatProps) {
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChat, setActiveChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [chatPartner, setChatPartner] = useState<UserProfile | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const q = query(collection(db, 'chats'), where('participants', 'array-contains', user.uid));
    const unsub = onSnapshot(q, (snap) => {
      setChats(snap.docs.map(d => ({ id: d.id, ...d.data() } as Chat)));
    });
    return unsub;
  }, [user.uid]);

  useEffect(() => {
    if (!activeChat) return;
    const q = query(collection(db, 'chats', activeChat.id, 'messages'), orderBy('ts', 'asc'), limit(50));
    const unsub = onSnapshot(q, (snap) => {
      setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() } as Message)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `chats/${activeChat.id}/messages`));

    const partnerId = activeChat.participants.find(p => p !== user.uid);
    if (partnerId) {
      getDocs(query(collection(db, 'users'), where('uid', '==', partnerId))).then(snap => {
        if (!snap.empty) setChatPartner(snap.docs[0].data() as UserProfile);
      });
    }

    return unsub;
  }, [activeChat, user.uid]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeChat) return;

    try {
      await addDoc(collection(db, 'chats', activeChat.id, 'messages'), {
        chatId: activeChat.id,
        senderUid: user.uid,
        text: newMessage,
        ts: Date.now()
      });
      setNewMessage('');
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `chats/${activeChat.id}/messages`);
    }
  };

  return (
    <div className="flex h-[calc(100vh-56px)] bg-white border-t">
      {/* Sidebar */}
      <div className="w-80 border-r flex flex-col">
        <div className="p-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold">Chats</h2>
          <div className="flex gap-2">
            <button className="p-2 bg-gray-100 rounded-full hover:bg-gray-200"><MoreHorizontal size={20} /></button>
            <button className="p-2 bg-gray-100 rounded-full hover:bg-gray-200"><Video size={20} /></button>
            <button className="p-2 bg-gray-100 rounded-full hover:bg-gray-200"><Edit3 size={20} /></button>
          </div>
        </div>
        <div className="px-4 mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
            <input 
              type="text" 
              placeholder="Buscar en Messenger" 
              className="w-full bg-gray-100 rounded-full pl-10 pr-4 py-2 text-sm outline-none"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {chats.map(chat => (
            <button 
              key={chat.id}
              onClick={() => setActiveChat(chat)}
              className={cn(
                "w-full flex items-center gap-3 p-3 hover:bg-gray-100 transition-colors",
                activeChat?.id === chat.id && "bg-blue-50"
              )}
            >
              <div className="relative">
                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${chat.id}`} className="w-12 h-12 rounded-full" />
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
              </div>
              <div className="flex-1 text-left min-w-0">
                <p className="font-semibold truncate">Chat {chat.id.slice(0, 5)}</p>
                <p className="text-xs text-gray-500 truncate">{chat.lastMessage || 'Inicia una conversación'}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Chat */}
      <div className="flex-1 flex flex-col bg-white">
        {activeChat ? (
          <>
            <div className="p-3 border-b flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <img src={chatPartner?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${activeChat.id}`} className="w-10 h-10 rounded-full" />
                <div>
                  <p className="font-bold">{chatPartner?.name || 'Cargando...'}</p>
                  <p className="text-xs text-gray-500">Activo ahora</p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-[#1877f2]">
                <Phone size={20} className="cursor-pointer" />
                <Video size={22} className="cursor-pointer" />
                <Info size={22} className="cursor-pointer" />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {messages.map((msg, idx) => {
                const isMe = msg.senderUid === user.uid;
                return (
                  <div key={msg.id} className={cn("flex", isMe ? "justify-end" : "justify-start")}>
                    {!isMe && (
                      <img src={chatPartner?.avatar} className="w-7 h-7 rounded-full self-end mr-2 mb-1" />
                    )}
                    <div className={cn(
                      "max-w-[70%] p-3 rounded-2xl text-sm",
                      isMe ? "bg-[#0084ff] text-white rounded-br-none" : "bg-gray-200 text-black rounded-bl-none"
                    )}>
                      {msg.text}
                    </div>
                  </div>
                );
              })}
              <div ref={scrollRef} />
            </div>

            <div className="p-4 flex items-center gap-3">
              <Plus className="text-[#1877f2] cursor-pointer" />
              <ImageIcon className="text-[#1877f2] cursor-pointer" />
              <Smile className="text-[#1877f2] cursor-pointer" />
              <form onSubmit={sendMessage} className="flex-1">
                <input 
                  type="text"
                  placeholder="Aa"
                  className="w-full bg-gray-100 rounded-full px-4 py-2 outline-none"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                />
              </form>
              <Send 
                className={cn("cursor-pointer", newMessage.trim() ? "text-[#1877f2]" : "text-gray-300")} 
                onClick={sendMessage}
              />
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-gray-500">
            <MessageCircle size={80} className="mb-4 opacity-20" />
            <p className="text-xl font-bold">Selecciona un chat para empezar</p>
          </div>
        )}
      </div>
    </div>
  );
}

import { Edit3, MessageCircle as MessageCircleIcon } from 'lucide-react';
