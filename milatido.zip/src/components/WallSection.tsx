import { useState, useEffect } from 'react';
import { 
  collection, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  doc, 
  getDoc,
  setDoc,
  updateDoc,
  arrayUnion,
  arrayRemove
} from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile, Post } from '../types';
import { cn } from '../lib/utils';
import { 
  Camera, 
  Edit3, 
  Plus, 
  MoreHorizontal, 
  Search,
  Grid,
  Video,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

interface WallProps {
  user: any;
  profile: UserProfile;
  wallUser: UserProfile;
  adminEmail: string;
  onBack: () => void;
  onUpdateProfile: (data: Partial<UserProfile>) => void;
}

export function WallSection({ user, profile, wallUser, adminEmail, onBack, onUpdateProfile }: WallProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<Partial<UserProfile>>(wallUser);

  useEffect(() => {
    const q = query(collection(db, 'posts'), where('uid', '==', wallUser.uid), orderBy('ts', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      setPosts(snap.docs.map(d => ({ id: d.id, ...d.data() } as Post)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `posts?uid=${wallUser.uid}`));
    return unsub;
  }, [wallUser.uid]);

  const isOwnWall = user.uid === wallUser.uid;

  return (
    <div className="bg-[#f0f2f5] min-h-screen">
      {/* Header / Cover */}
      <div className="bg-white shadow">
        <div className="max-w-[1100px] mx-auto">
          <div className="relative h-[350px] bg-gray-200 rounded-b-xl overflow-hidden group">
            <img 
              src={wallUser.coverPhoto || `https://picsum.photos/seed/${wallUser.uid}/1100/350`} 
              className="w-full h-full object-cover" 
              referrerPolicy="no-referrer"
            />
            {isOwnWall && (
              <button className="absolute bottom-4 right-4 bg-white px-3 py-2 rounded-lg font-bold flex items-center gap-2 shadow hover:bg-gray-100 transition-colors">
                <Camera size={20} /> Editar foto de portada
              </button>
            )}
          </div>

          <div className="px-8 pb-4 flex flex-col md:flex-row items-end gap-4 -mt-10 relative z-10">
            <div className="relative group">
              <img 
                src={wallUser.avatar} 
                className="w-40 h-40 rounded-full border-4 border-white object-cover bg-white" 
              />
              {isOwnWall && (
                <button className="absolute bottom-2 right-2 bg-gray-200 p-2 rounded-full hover:bg-gray-300">
                  <Camera size={20} />
                </button>
              )}
            </div>
            <div className="flex-1 mb-4">
              <h1 className="text-3xl font-bold">{wallUser.name}</h1>
              <p className="text-gray-500 font-semibold">{wallUser.friends?.length || 0} amigos</p>
              <div className="flex -space-x-2 mt-2">
                {[1,2,3,4,5].map(i => (
                  <img key={i} src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i}`} className="w-8 h-8 rounded-full border-2 border-white" />
                ))}
              </div>
            </div>
            <div className="flex gap-2 mb-4">
              {isOwnWall ? (
                <>
                  <button className="bg-[#1877f2] text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-[#166fe5]">
                    <Plus size={20} /> Agregar a historia
                  </button>
                  <button 
                    onClick={() => setIsEditing(true)}
                    className="bg-gray-200 px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-gray-300"
                  >
                    <Edit3 size={20} /> Editar perfil
                  </button>
                </>
              ) : (
                <>
                  <button className="bg-[#1877f2] text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2">
                    <Users size={20} /> Amigos
                  </button>
                  <button className="bg-gray-200 px-4 py-2 rounded-lg font-bold">Mensaje</button>
                </>
              )}
            </div>
          </div>

          <hr className="mx-8" />
          
          <div className="px-8 flex items-center justify-between">
            <div className="flex">
              {['Publicaciones', 'Información', 'Amigos', 'Fotos', 'Videos', 'Más'].map((tab, idx) => (
                <button 
                  key={tab}
                  className={cn(
                    "px-4 py-4 font-semibold text-gray-500 hover:bg-gray-100 transition-colors relative",
                    idx === 0 && "text-[#1877f2]"
                  )}
                >
                  {tab}
                  {idx === 0 && <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-[#1877f2]" />}
                </button>
              ))}
            </div>
            <button className="p-2 bg-gray-200 rounded-lg hover:bg-gray-300">
              <MoreHorizontal />
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-[1100px] mx-auto py-4 px-4 flex flex-col lg:flex-row gap-4">
        {/* Left Col - Intro */}
        <div className="lg:w-[400px] space-y-4">
          <div className="bg-white rounded-lg shadow p-4">
            <h3 className="text-xl font-bold mb-4">Introducción</h3>
            <div className="space-y-4">
              {wallUser.bio && <p className="text-center text-sm">{wallUser.bio}</p>}
              <button 
                onClick={() => isOwnWall && setIsEditing(true)}
                className="w-full bg-gray-200 py-2 rounded-lg font-bold hover:bg-gray-300 transition-colors"
              >
                {wallUser.bio ? 'Editar biografía' : 'Agregar biografía'}
              </button>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <Grid size={20} /> <span>Vive en <span className="font-bold">{wallUser.city || 'Desconocido'}</span></span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Video size={20} /> <span>De <span className="font-bold">{wallUser.country || 'Desconocido'}</span></span>
                </div>
              </div>
              <button className="w-full bg-gray-200 py-2 rounded-lg font-bold hover:bg-gray-300 transition-colors">
                Editar detalles
              </button>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">Fotos</h3>
              <button className="text-[#1877f2] hover:bg-blue-50 px-2 py-1 rounded">Ver todas las fotos</button>
            </div>
            <div className="grid grid-cols-3 gap-1 rounded-lg overflow-hidden">
              {[1,2,3,4,5,6,7,8,9].map(i => (
                <img key={i} src={`https://picsum.photos/seed/p${i}/200/200`} className="aspect-square object-cover" referrerPolicy="no-referrer" />
              ))}
            </div>
          </div>
        </div>

        {/* Right Col - Posts */}
        <div className="flex-1 space-y-4">
          {isOwnWall && (
            <div className="bg-white rounded-lg shadow p-4">
              <div className="flex gap-2 mb-4">
                <img src={profile.avatar} className="w-10 h-10 rounded-full" />
                <button className="flex-1 bg-[#f0f2f5] hover:bg-gray-200 rounded-full px-4 text-left text-gray-500">
                  ¿Qué estás pensando?
                </button>
              </div>
              <hr className="mb-2" />
              <div className="flex justify-around">
                <button className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg flex-1 justify-center font-semibold text-gray-600">
                  <Video className="text-red-500" /> Video en vivo
                </button>
                <button className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg flex-1 justify-center font-semibold text-gray-600">
                  <Camera className="text-green-500" /> Foto/video
                </button>
                <button className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg flex-1 justify-center font-semibold text-gray-600">
                  <Plus className="text-blue-500" /> Acontecimiento importante
                </button>
              </div>
            </div>
          )}

          <div className="bg-white rounded-lg shadow p-4 flex items-center justify-between">
            <h3 className="text-xl font-bold">Publicaciones</h3>
            <div className="flex gap-2">
              <button className="bg-gray-200 px-3 py-2 rounded-lg font-bold flex items-center gap-2"><Grid size={18} /> Filtros</button>
              <button className="bg-gray-200 px-3 py-2 rounded-lg font-bold flex items-center gap-2"><Edit3 size={18} /> Administrar publicaciones</button>
            </div>
          </div>

          {posts.map(post => (
            <div key={post.id} className="bg-white rounded-lg shadow p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <img src={post.avatar} className="w-10 h-10 rounded-full" />
                  <div>
                    <p className="font-bold">{post.name}</p>
                    <p className="text-xs text-gray-500">Hace un momento</p>
                  </div>
                </div>
                <MoreHorizontal className="text-gray-500" />
              </div>
              <p className="mb-4">{post.text}</p>
              {post.image && <img src={post.image} className="w-full rounded-lg mb-4" referrerPolicy="no-referrer" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
