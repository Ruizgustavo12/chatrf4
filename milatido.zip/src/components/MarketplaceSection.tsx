import { useState, useEffect } from 'react';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy, 
  addDoc, 
  serverTimestamp,
  doc,
  updateDoc,
  deleteDoc,
  where
} from 'firebase/firestore';
import { db } from '../firebase';
import { MarketplaceListing, UserProfile } from '../types';
import { 
  Search, 
  Plus, 
  MapPin, 
  Tag, 
  Grid, 
  List,
  MessageCircle,
  X,
  Camera
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

interface MarketplaceProps {
  user: any;
  profile: UserProfile;
}

export function MarketplaceSection({ user, profile }: MarketplaceProps) {
  const [listings, setListings] = useState<MarketplaceListing[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState('Varios');
  const [newImage, setNewImage] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'marketplace'), orderBy('ts', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      setListings(snap.docs.map(d => ({ id: d.id, ...d.data() } as MarketplaceListing)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'marketplace'));
    return unsub;
  }, []);

  const handleCreateListing = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newPrice) return;

    try {
      await addDoc(collection(db, 'marketplace'), {
        title: newTitle,
        price: Number(newPrice),
        description: newDesc,
        category: newCategory,
        image: newImage || `https://picsum.photos/seed/${newTitle}/400/400`,
        location: profile.city || 'Ubicación no especificada',
        sellerUid: user.uid,
        sellerName: profile.name,
        sellerAvatar: profile.avatar,
        ts: Date.now()
      });
      setIsCreating(false);
      setNewTitle('');
      setNewPrice('');
      setNewDesc('');
      setNewImage('');
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'marketplace');
    }
  };

  return (
    <div className="flex h-[calc(100vh-56px)] bg-[#f0f2f5]">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r flex flex-col p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Marketplace</h2>
          <button className="p-2 bg-gray-100 rounded-full hover:bg-gray-200"><Search size={20} /></button>
        </div>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
          <input 
            type="text" 
            placeholder="Buscar en Marketplace" 
            className="w-full bg-gray-100 rounded-full pl-10 pr-4 py-2 text-sm outline-none"
          />
        </div>

        <button 
          onClick={() => setIsCreating(true)}
          className="w-full bg-blue-50 text-[#1877f2] py-2 rounded-lg font-bold flex items-center justify-center gap-2 hover:bg-blue-100 transition-colors"
        >
          <Plus size={20} /> Crear nueva publicación
        </button>

        <div className="space-y-1 overflow-y-auto">
          <h3 className="font-bold text-sm text-gray-500 px-2 py-2">Categorías</h3>
          {['Vehículos', 'Alquileres', 'Electrónica', 'Entretenimiento', 'Familia', 'Jardín y aire libre'].map(cat => (
            <button key={cat} className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors text-sm font-semibold">
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <Tag size={16} />
              </div>
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-[1200px] mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold">Sugerencias de hoy</h3>
            <div className="flex items-center gap-2 text-[#1877f2] font-semibold cursor-pointer hover:underline">
              <MapPin size={18} /> {profile.city || 'Tu ubicación'}
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {listings.map(item => (
              <div key={item.id} className="bg-white rounded-xl shadow overflow-hidden cursor-pointer group">
                <div className="aspect-square overflow-hidden">
                  <img 
                    src={item.image} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform" 
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-3">
                  <p className="font-bold text-lg">${item.price.toLocaleString()}</p>
                  <p className="text-sm truncate">{item.title}</p>
                  <p className="text-xs text-gray-500 mt-1">{item.location}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Create Listing Modal */}
      <AnimatePresence>
        {isCreating && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-xl shadow-2xl w-full max-w-[600px] overflow-hidden flex flex-col md:flex-row h-[500px]"
            >
              <div className="w-full md:w-1/2 bg-gray-100 p-6 flex flex-col items-center justify-center border-r">
                <div className="w-full aspect-square bg-white rounded-xl border-2 border-dashed border-gray-300 flex flex-col items-center justify-center text-gray-400">
                  {newImage ? (
                    <img src={newImage} className="w-full h-full object-cover rounded-xl" />
                  ) : (
                    <>
                      <Camera size={48} className="mb-2" />
                      <p className="text-sm font-bold">Agregar fotos</p>
                    </>
                  )}
                </div>
                <input 
                  type="text" 
                  placeholder="URL de imagen" 
                  className="w-full mt-4 p-2 text-xs border rounded outline-none"
                  value={newImage}
                  onChange={(e) => setNewImage(e.target.value)}
                />
              </div>
              
              <div className="flex-1 flex flex-col">
                <div className="p-4 border-b flex items-center justify-between">
                  <h3 className="text-xl font-bold">Artículo en venta</h3>
                  <button onClick={() => setIsCreating(false)} className="p-2 bg-gray-100 rounded-full hover:bg-gray-200">
                    <X size={20} />
                  </button>
                </div>
                <form onSubmit={handleCreateListing} className="p-4 space-y-4 flex-1 overflow-y-auto">
                  <input 
                    type="text" 
                    placeholder="Título" 
                    className="w-full p-3 border rounded-lg outline-none focus:border-blue-500"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    required
                  />
                  <input 
                    type="number" 
                    placeholder="Precio" 
                    className="w-full p-3 border rounded-lg outline-none focus:border-blue-500"
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    required
                  />
                  <select 
                    className="w-full p-3 border rounded-lg outline-none focus:border-blue-500 bg-white"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                  >
                    <option>Varios</option>
                    <option>Vehículos</option>
                    <option>Electrónica</option>
                    <option>Hogar</option>
                  </select>
                  <textarea 
                    placeholder="Descripción" 
                    className="w-full p-3 border rounded-lg outline-none focus:border-blue-500 min-h-[100px]"
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                  />
                  <button 
                    type="submit"
                    className="w-full bg-[#1877f2] text-white py-3 rounded-lg font-bold hover:bg-[#166fe5] transition-colors"
                  >
                    Publicar
                  </button>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
