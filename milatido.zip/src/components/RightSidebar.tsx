import { 
  Gift, 
  Search, 
  MoreHorizontal, 
  Video
} from 'lucide-react';
import { UserProfile } from '../types';

interface RightSidebarProps {
  onlineUsers: UserProfile[];
  onOpenWall: (profile: UserProfile) => void;
}

export function RightSidebar({ onlineUsers, onOpenWall }: RightSidebarProps) {
  return (
    <aside className="hidden xl:flex flex-col w-80 h-full overflow-y-auto p-4 scrollbar-hide space-y-6">
      <section>
        <h3 className="text-gray-500 font-bold text-sm mb-4">Publicidad</h3>
        <div className="space-y-4">
          <a href="#" className="flex items-center gap-3 group">
            <img 
              src="https://picsum.photos/seed/ads1/200/200" 
              className="w-28 h-28 rounded-xl object-cover" 
              referrerPolicy="no-referrer"
            />
            <div className="flex-1">
              <p className="text-sm font-semibold group-hover:underline">Invertí hoy mismo</p>
              <p className="text-xs text-gray-500">latido-invest.com</p>
            </div>
          </a>
        </div>
      </section>

      <section className="pt-4 border-t border-gray-200">
        <h3 className="text-gray-500 font-bold text-sm mb-4">Cumpleaños</h3>
        <div className="flex items-center gap-3">
          <Gift className="text-blue-500" size={24} />
          <p className="text-sm">
            Hoy es el cumpleaños de <span className="font-bold">Juan Pérez</span> y <span className="font-bold">2 personas más</span>.
          </p>
        </div>
      </section>

      <section className="pt-4 border-t border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-gray-500 font-bold text-sm">Contactos</h3>
          <div className="flex items-center gap-3 text-gray-500">
            <Video size={16} className="cursor-pointer hover:text-black" />
            <Search size={16} className="cursor-pointer hover:text-black" />
            <MoreHorizontal size={16} className="cursor-pointer hover:text-black" />
          </div>
        </div>
        
        <div className="space-y-1">
          {onlineUsers.map((u) => (
            <button 
              key={u.uid}
              onClick={() => onOpenWall(u)}
              className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-gray-200 transition-colors relative group"
            >
              <div className="relative">
                <img src={u.avatar} className="w-9 h-9 rounded-full object-cover border border-gray-200" />
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
              </div>
              <span className="font-semibold text-sm">{u.name}</span>
            </button>
          ))}
        </div>
      </section>
    </aside>
  );
}
