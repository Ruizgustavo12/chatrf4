import { useState, useEffect } from 'react';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy, 
  addDoc, 
  serverTimestamp,
  doc,
  updateDoc,
  arrayUnion,
  arrayRemove,
  deleteDoc
} from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile, Post, Story } from '../types';
import { formatDate, cn } from '../lib/utils';
import { 
  Image as ImageIcon, 
  Video, 
  Smile, 
  MoreHorizontal, 
  ThumbsUp, 
  MessageCircle, 
  Share2,
  Plus,
  Trash2,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

interface FeedProps {
  user: any;
  profile: UserProfile;
  adminEmail: string;
  onOpenWall: (profile: UserProfile) => void;
}

export function FeedSection({ user, profile, adminEmail, onOpenWall }: FeedProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [newPostText, setNewPostText] = useState('');
  const [newPostImage, setNewPostImage] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'posts'), orderBy('ts', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      setPosts(snap.docs.map(d => ({ id: d.id, ...d.data() } as Post)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'posts'));
    return unsub;
  }, []);

  useEffect(() => {
    // Simplified stories for now
    return () => {};
  }, []);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim() && !newPostImage) return;

    try {
      await addDoc(collection(db, 'posts'), {
        uid: user.uid,
        name: profile.name,
        avatar: profile.avatar,
        text: newPostText,
        image: newPostImage,
        ts: serverTimestamp(),
        likes: [],
        commentCount: 0
      });
      setNewPostText('');
      setNewPostImage('');
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'posts');
    }
  };

  return (
    <div className="space-y-4">
      {/* Stories */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
        <div className="relative flex-shrink-0 w-28 h-48 rounded-xl overflow-hidden cursor-pointer group bg-gray-200">
          <img src={profile.avatar} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
          <div className="absolute inset-0 bg-black/20" />
          <div className="absolute bottom-0 left-0 right-0 p-2 bg-white h-12 flex flex-col items-center">
            <div className="absolute -top-4 w-8 h-8 bg-[#1877f2] rounded-full border-4 border-white flex items-center justify-center text-white">
              <Plus size={20} />
            </div>
            <span className="text-[11px] font-bold mt-3">Crear historia</span>
          </div>
        </div>
        {[1, 2, 3, 4, 5].map(i => (
          <div key={i} className="relative flex-shrink-0 w-28 h-48 rounded-xl overflow-hidden cursor-pointer group">
            <img src={`https://picsum.photos/seed/story${i}/200/300`} className="w-full h-full object-cover group-hover:scale-105 transition-transform" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60" />
            <div className="absolute top-2 left-2 w-8 h-8 rounded-full border-2 border-[#1877f2] overflow-hidden">
              <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=user${i}`} className="w-full h-full" />
            </div>
            <span className="absolute bottom-2 left-2 text-white text-[11px] font-bold">Amigo {i}</span>
          </div>
        ))}
      </div>

      {/* Create Post */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex gap-2 mb-4">
          <img src={profile.avatar} className="w-10 h-10 rounded-full object-cover" />
          <button 
            onClick={() => setNewPostText(' ')} // Trigger focus
            className="flex-1 bg-[#f0f2f5] hover:bg-gray-200 rounded-full px-4 text-left text-gray-500 transition-colors"
          >
            ¿Qué estás pensando, {profile.name.split(' ')[0]}?
          </button>
        </div>
        <hr className="mb-3" />
        <div className="flex justify-around">
          <button className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-colors flex-1 justify-center">
            <Video className="text-red-500" size={24} />
            <span className="text-sm font-semibold text-gray-600">Video en vivo</span>
          </button>
          <button className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-colors flex-1 justify-center">
            <ImageIcon className="text-green-500" size={24} />
            <span className="text-sm font-semibold text-gray-600">Foto/video</span>
          </button>
          <button className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-colors flex-1 justify-center">
            <Smile className="text-yellow-500" size={24} />
            <span className="text-sm font-semibold text-gray-600">Sentimiento/actividad</span>
          </button>
        </div>
      </div>

      {/* Posts Feed */}
      <AnimatePresence>
        {posts.map(post => (
          <PostItem 
            key={post.id} 
            post={post} 
            user={user} 
            adminEmail={adminEmail} 
            onOpenWall={onOpenWall}
          />
        ))}
      </AnimatePresence>

      {/* Post Modal (Simplified) */}
      {newPostText !== '' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/80 backdrop-blur-sm">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-lg shadow-2xl w-full max-w-[500px] overflow-hidden"
          >
            <div className="p-4 border-b flex items-center justify-between">
              <h3 className="text-xl font-bold text-center flex-1">Crear publicación</h3>
              <button onClick={() => setNewPostText('')} className="p-2 bg-gray-200 rounded-full hover:bg-gray-300">
                <Plus className="rotate-45" />
              </button>
            </div>
            <div className="p-4">
              <div className="flex items-center gap-2 mb-4">
                <img src={profile.avatar} className="w-10 h-10 rounded-full" />
                <div>
                  <p className="font-bold">{profile.name}</p>
                  <div className="bg-gray-200 px-2 py-0.5 rounded flex items-center gap-1 text-xs font-bold">
                    <Users size={12} /> Amigos
                  </div>
                </div>
              </div>
              <textarea 
                className="w-full text-xl outline-none resize-none min-h-[150px]"
                placeholder={`¿Qué estás pensando, ${profile.name.split(' ')[0]}?`}
                value={newPostText}
                onChange={(e) => setNewPostText(e.target.value)}
              />
              <input 
                type="text"
                placeholder="URL de imagen (opcional)"
                className="w-full p-2 bg-gray-100 rounded mb-4 text-sm"
                value={newPostImage}
                onChange={(e) => setNewPostImage(e.target.value)}
              />
              <button 
                onClick={handleCreatePost}
                disabled={!newPostText.trim() && !newPostImage}
                className="w-full bg-[#1877f2] text-white py-2 rounded-lg font-bold disabled:opacity-50"
              >
                Publicar
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

function PostItem({ post, user, adminEmail, onOpenWall }: { post: Post; user: any; adminEmail: string; onOpenWall: (p: UserProfile) => void }) {
  const isLiked = post.likes.includes(user.uid);

  const toggleLike = async () => {
    const postRef = doc(db, 'posts', post.id);
    try {
      await updateDoc(postRef, {
        likes: isLiked ? arrayRemove(user.uid) : arrayUnion(user.uid)
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `posts/${post.id}`);
    }
  };

  const handleDelete = async () => {
    if (!confirm('¿Seguro que querés eliminar esta publicación?')) return;
    try {
      await deleteDoc(doc(db, 'posts', post.id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `posts/${post.id}`);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-white rounded-lg shadow"
    >
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <img 
            src={post.avatar} 
            className="w-10 h-10 rounded-full cursor-pointer" 
            onClick={() => onOpenWall({ uid: post.uid, name: post.name, avatar: post.avatar } as any)}
          />
          <div>
            <p className="font-bold hover:underline cursor-pointer" onClick={() => onOpenWall({ uid: post.uid, name: post.name, avatar: post.avatar } as any)}>
              {post.name}
            </p>
            <p className="text-xs text-gray-500">{formatDate(post.ts)}</p>
          </div>
        </div>
        <div className="flex gap-2">
          {(post.uid === user.uid || user.email === adminEmail) && (
            <button onClick={handleDelete} className="p-2 text-gray-400 hover:text-red-500">
              <Trash2 size={18} />
            </button>
          )}
          <button className="p-2 text-gray-400 hover:bg-gray-100 rounded-full">
            <MoreHorizontal size={20} />
          </button>
        </div>
      </div>

      <div className="px-4 pb-3 text-sm text-gray-800">
        {post.text}
      </div>

      {post.image && (
        <div className="bg-gray-100">
          <img src={post.image} className="w-full max-h-[500px] object-contain mx-auto" referrerPolicy="no-referrer" />
        </div>
      )}

      <div className="px-4 py-2 flex items-center justify-between text-sm text-gray-500 border-b mx-4">
        <div className="flex items-center gap-1">
          <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
            <ThumbsUp size={10} fill="white" className="text-white" />
          </div>
          <span>{post.likes.length}</span>
        </div>
        <div className="flex gap-3">
          <span>{post.commentCount || 0} comentarios</span>
          <span>Compartido 0 veces</span>
        </div>
      </div>

      <div className="px-4 py-1 flex">
        <button 
          onClick={toggleLike}
          className={cn(
            "flex-1 py-1.5 flex items-center justify-center gap-2 font-semibold transition-colors rounded hover:bg-gray-100",
            isLiked ? "text-blue-600" : "text-gray-600"
          )}
        >
          <ThumbsUp size={20} fill={isLiked ? "currentColor" : "none"} />
          Me gusta
        </button>
        <button className="flex-1 py-1.5 flex items-center justify-center gap-2 font-semibold text-gray-600 hover:bg-gray-100 rounded transition-colors">
          <MessageCircle size={20} />
          Comentar
        </button>
        <button className="flex-1 py-1.5 flex items-center justify-center gap-2 font-semibold text-gray-600 hover:bg-gray-100 rounded transition-colors">
          <Share2 size={20} />
          Compartir
        </button>
      </div>
    </motion.div>
  );
}
