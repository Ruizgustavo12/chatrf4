export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  avatar: string;
  coverPhoto?: string;
  bio?: string;
  city?: string;
  country?: string;
  friends: string[];
  friendRequests: string[];
}

export interface Post {
  id: string;
  uid: string;
  name: string;
  avatar: string;
  text: string;
  image?: string;
  video?: string;
  ts: any;
  likes: string[];
  commentCount: number;
}

export interface Comment {
  id: string;
  postId: string;
  uid: string;
  name: string;
  avatar: string;
  text: string;
  ts: any;
}

export interface Chat {
  id: string;
  participants: string[];
  lastMessage?: string;
  lastTs?: number;
}

export interface Message {
  id: string;
  chatId: string;
  senderUid: string;
  text: string;
  image?: string;
  ts: number;
}

export interface Notification {
  id: string;
  type: 'friend_request' | 'like' | 'comment' | 'message' | 'group_invite' | 'group_request';
  fromUid: string;
  fromName: string;
  fromAvatar: string;
  read: boolean;
  ts: any;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  cover?: string;
  adminUid: string;
  members: string[];
  pendingRequests: string[];
  privacy: 'public' | 'private';
  ts: number;
}

export interface MarketplaceListing {
  id: string;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
  location: string;
  sellerUid: string;
  sellerName: string;
  sellerAvatar: string;
  ts: number;
}

export interface Story {
  id: string;
  uid: string;
  name: string;
  avatar: string;
  text: string;
  imageUrl?: string;
  ts: number;
  expiresAt: number;
}
