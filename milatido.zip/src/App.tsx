import { useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signOut,
  User
} from 'firebase/auth';
import { 
  collection, 
  onSnapshot, 
  doc, 
  getDoc, 
  setDoc,
  query,
  where,
  orderBy,
  limit
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { UserProfile } from './types';
import { 
  Bell, 
  MessageCircle, 
  Home, 
  Users, 
  Search, 
  PlaySquare, 
  Store, 
  Gamepad2,
  Grid,
  LogOut
} from 'lucide-react';
import { cn } from './lib/utils';
import { handleFirestoreError, OperationType } from './lib/firestore-errors';

// Components
import { ErrorBoundary } from './components/ErrorBoundary';
import { AuthSection } from './components/AuthSection';
import { ChatSection } from './components/ChatSection';
import { WallSection } from './components/WallSection';
import { FeedSection } from './components/FeedSection';
import { SearchSection } from './components/SearchSection';
import { Sidebar } from './components/Sidebar';
import { RightSidebar } from './components/RightSidebar';
import { GroupsSection } from './components/GroupsSection';
import { MarketplaceSection } from './components/MarketplaceSection';

const ADMIN_EMAIL = "synxyes@gmail.com";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'feed' | 'wall' | 'chat' | 'search' | 'video' | 'market' | 'groups' | 'gaming'>('feed');
  const [wallUser, setWallUser] = useState<UserProfile | null>(null);
  const [onlineUsers, setOnlineUsers] = useState<UserProfile[]>([]);
  const [notifCount, setNotifCount] = useState(0);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const userDoc = await getDoc(doc(db, 'users', u.uid));
        if (userDoc.exists()) {
          setProfile(userDoc.data() as UserProfile);
        }
        updateOnlineStatus(u.uid);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'online'), where('online', '==', true), limit(10));
    const unsub = onSnapshot(q, async (snap) => {
      const profiles: UserProfile[] = [];
      for (const d of snap.docs) {
        if (d.id === user.uid) continue;
        try {
          const pDoc = await getDoc(doc(db, 'users', d.id));
          if (pDoc.exists()) profiles.push(pDoc.data() as UserProfile);
        } catch (e) {
          console.error("Error fetching online user profile:", e);
        }
      }
      setOnlineUsers(profiles);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'online'));
    return unsub;
  }, [user]);

  const updateOnlineStatus = async (uid: string) => {
    await setDoc(doc(db, 'online', uid), { online: true, ts: Date.now() });
  };

  const openWall = (target: UserProfile) => {
    setWallUser(target);
    setView('wall');
  };

  const handleUpdateProfile = async (data: Partial<UserProfile>) => {
    if (!user) return;
    await setDoc(doc(db, 'users', user.uid), data, { merge: true });
    setProfile(prev => prev ? { ...prev, ...data } : null);
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-[#f0f2f5]">
        <div className="w-12 h-12 border-4 border-[#1877f2] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <ErrorBoundary>
        <AuthSection />
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <div className="flex flex-col h-screen bg-[#f0f2f5] overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow px-4 h-14 flex items-center justify-between z-30 sticky top-0">
          <div className="flex items-center gap-2 flex-1">
            <div 
              className="w-10 h-10 bg-[#1877f2] rounded-full flex items-center justify-center cursor-pointer"
              onClick={() => setView('feed')}
            >
              <span className="text-white font-black text-2xl">M</span>
            </div>
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
              <input 
                type="text"
                placeholder="Buscar en MiLatido"
                className="bg-[#f0f2f5] rounded-full pl-10 pr-4 py-2 text-sm outline-none w-64 focus:bg-gray-200 transition-colors"
                onClick={() => setView('search')}
              />
            </div>
          </div>
          
          <nav className="hidden lg:flex items-center gap-1 flex-1 justify-center">
            {[
              { icon: Home, view: 'feed', label: 'Inicio' },
              { icon: PlaySquare, view: 'video', label: 'Video' },
              { icon: Store, view: 'market', label: 'Marketplace' },
              { icon: Users, view: 'groups', label: 'Grupos' },
              { icon: Gamepad2, view: 'gaming', label: 'Gaming' },
            ].map((item) => (
              <button 
                key={item.view}
                onClick={() => setView(item.view as any)}
                title={item.label}
                className={cn(
                  "px-10 h-14 flex items-center justify-center relative transition-colors",
                  view === item.view ? "text-[#1877f2]" : "text-gray-500 hover:bg-gray-100 hover:rounded-xl"
                )}
              >
                <item.icon size={26} strokeWidth={view === item.view ? 2.5 : 2} />
                {view === item.view && (
                  <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-[#1877f2]" />
                )}
              </button>
            ))}
          </nav>

          <div className="flex items-center justify-end gap-2 flex-1">
            <button className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-black hover:bg-gray-300 transition-colors">
              <Grid size={20} />
            </button>
            <button 
              onClick={() => setView('chat')}
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center transition-colors",
                view === 'chat' ? "bg-blue-100 text-[#1877f2]" : "bg-gray-200 text-black hover:bg-gray-300"
              )}
            >
              <MessageCircle size={20} />
            </button>
            <div className="relative">
              <button className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-black hover:bg-gray-300 transition-colors">
                <Bell size={20} />
              </button>
              {notifCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-[11px] font-bold px-1.5 py-0.5 rounded-full border-2 border-white text-white">
                  {notifCount}
                </span>
              )}
            </div>
            <div className="relative group">
              <button 
                onClick={() => openWall(profile!)}
                className="w-10 h-10 rounded-full overflow-hidden border border-gray-200 ml-2"
              >
                <img src={profile?.avatar} className="w-full h-full object-cover" />
              </button>
              <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-xl border hidden group-hover:block p-2">
                <button 
                  onClick={() => signOut(auth)}
                  className="w-full flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg text-sm font-bold text-red-600"
                >
                  <LogOut size={18} /> Cerrar sesión
                </button>
              </div>
            </div>
          </div>
        </header>

        <div className="flex flex-1 overflow-hidden">
          {view === 'feed' && profile && (
            <Sidebar profile={profile} onOpenWall={openWall} />
          )}

          <main className="flex-1 overflow-y-auto scrollbar-hide bg-[#f0f2f5]">
            <div className={cn(
              "mx-auto",
              view === 'feed' ? "max-w-[740px] py-4" : "w-full"
            )}>
              {view === 'feed' ? (
                <FeedSection 
                  user={user} 
                  profile={profile!} 
                  adminEmail={ADMIN_EMAIL} 
                  onOpenWall={openWall} 
                />
              ) : view === 'search' ? (
                <SearchSection 
                  user={user} 
                  profile={profile!} 
                  onOpenWall={openWall} 
                />
              ) : view === 'chat' ? (
                <ChatSection 
                  user={user} 
                  profile={profile!} 
                />
              ) : view === 'wall' ? (
                <WallSection 
                  user={user} 
                  profile={profile!} 
                  wallUser={wallUser!} 
                  adminEmail={ADMIN_EMAIL} 
                  onBack={() => setView('feed')} 
                  onUpdateProfile={handleUpdateProfile}
                />
              ) : view === 'groups' ? (
                <GroupsSection 
                  user={user} 
                  profile={profile!} 
                />
              ) : view === 'market' ? (
                <MarketplaceSection 
                  user={user} 
                  profile={profile!} 
                />
              ) : (
                <div className="flex flex-col items-center justify-center h-full py-20 text-gray-500">
                  <PlaySquare size={80} className="mb-4 opacity-20" />
                  <p className="text-2xl font-bold">Sección en desarrollo</p>
                  <button onClick={() => setView('feed')} className="mt-4 text-[#1877f2] font-bold hover:underline">Volver al inicio</button>
                </div>
              )}
            </div>
          </main>

          {view === 'feed' && (
            <RightSidebar onlineUsers={onlineUsers} onOpenWall={openWall} />
          )}
        </div>
      </div>
    </ErrorBoundary>
  );
}
